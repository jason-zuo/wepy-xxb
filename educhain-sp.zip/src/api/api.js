import wepy from "wepy" ;

const host = "" ;  //定义api请求的host从而区分测试以及真实环境

// 对小程序的request进行简单的二次封装
const wxRequest = async (params = {} , url) => {
  wepy.showToast({
    title : "加载中" ,
    icon : "loading"
  })

  let res = await wepy.request({
      url : url ,
      method: params.method || "GET" ,
      data: params.data || {} ,
      header : {'Content-Type' : 'application/json'}

  })
  wepy.hideToast() ;
  return res ;
};

// 以下具体展示使用到的api列表 具体post参数在params.query

const getLesson = (params) => wxRequest(params, host + "") ;


module.exports = {


};
